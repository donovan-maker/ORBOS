import getpass

print('ORB Settings v1.0.0')
print('''
░██████╗███████╗████████╗████████╗██╗███╗░░██╗░██████╗░░██████╗
██╔════╝██╔════╝╚══██╔══╝╚══██╔══╝██║████╗░██║██╔════╝░██╔════╝
╚█████╗░█████╗░░░░░██║░░░░░░██║░░░██║██╔██╗██║██║░░██╗░╚█████╗░
░╚═══██╗██╔══╝░░░░░██║░░░░░░██║░░░██║██║╚████║██║░░╚██╗░╚═══██╗
██████╔╝███████╗░░░██║░░░░░░██║░░░██║██║░╚███║╚██████╔╝██████╔╝
╚═════╝░╚══════╝░░░╚═╝░░░░░░╚═╝░░░╚═╝╚═╝░░╚══╝░╚═════╝░╚═════╝░
''')

while True:
    do = input('[1] Profile\n[2] Reset\n[3] Help\n[4] exit')

    if do == '1':
        lols = open('C__/orb/system32/.dat', 'r').readlines()
        print('Username: ' + lols[1])
        print('Password: ' + lols[2])
        do = input('[1] Exit\n[2] Change Username\n[3] Change Password ')
        if do == '2':
            lols[1] = input('New username: ') + '\n'
        elif do == '3':
            lols[2] = getpass.getpass(prompt='New password: ', stream=None) + '\n'
        open('C__/orb/system32/.dat', 'w').writelines(lols)
    elif do == '2':
        open('C__/orb/system32/.dat', 'w').writelines(open('C__/Programs/settings/setting.dat-default.dat', 'r').readlines())
    elif do == '3':
        print(open('C__/Programs/settings/settingshelp.dat', 'r').read())
    elif do == '4':
        print('Closing')
        break