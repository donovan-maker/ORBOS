import os
import getpass

if open('C__/orb/system32/.dat', 'r').readlines()[0] ==  '0\n':
    print('Loading setup...')
    username = input('Please enter a username: ')
    password = getpass.getpass(prompt='Please enter a password: ', stream=None)
    lols = open('C__/orb/system32/.dat', 'r').readlines()
    lols[0] = '1\n'
    lols[1] = username + '\n'
    lols[2] = password + '\n'
    open('C__/orb/system32/.dat', 'w').writelines(lols)
    input('Press enter to shutdown')
else:
    print('Hello, ' + open('C__/orb/system32/.dat', 'r').readlines()[1])
    pwi = getpass.getpass(prompt='Please enter your password: ', stream=None)
    if pwi + '\n' == open('C__/orb/system32/.dat', 'r').readlines()[2]:
        print('Correct, starting up home...')
        os.system('python3 C__/start/home.py')
    elif pwi == '/reset':
        lols = open('C__/orb/system32/.dat', 'r').readlines()
        lols[0] = '0\n'
        lols[1] = '\n'
        lols[2] = '\n'
        open('C__/orb/system32/.dat', 'w').writelines(lols)
        print('Reset setup')
        input('Press enter to shutdown')
    else:
        print('Wrong')
        input('Press enter to shutdown')