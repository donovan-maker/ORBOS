import os
import time
import sys

os.system('clear')
start = time.time()
print('Starting ORB.')
def spinning_cursor():
    while True:
        for cursor in '|/-\\':
            yield cursor

spinner = spinning_cursor()
for _ in range(30):
    sys.stdout.write(next(spinner))
    sys.stdout.flush()
    time.sleep(0.1)
    sys.stdout.write('\b')

print('Started ORB.')
print('''
░█████╗░██████╗░██████╗░  ░█████╗░░██████╗
██╔══██╗██╔══██╗██╔══██╗  ██╔══██╗██╔════╝
██║░░██║██████╔╝██████╦╝  ██║░░██║╚█████╗░
██║░░██║██╔══██╗██╔══██╗  ██║░░██║░╚═══██╗
╚█████╔╝██║░░██║██████╦╝  ╚█████╔╝██████╔╝
░╚════╝░╚═╝░░╚═╝╚═════╝░  ░╚════╝░╚═════╝░
''')
print('Getting login...')
os.system('python3 C__/orb/bootable/login.py')
