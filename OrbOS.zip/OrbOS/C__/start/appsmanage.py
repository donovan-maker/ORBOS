import os

def run(app, type):
    if type == 'open':
        os.system('python3 C__/Programs/' + app.lower() + '/main.py')