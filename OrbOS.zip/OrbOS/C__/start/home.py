import os
from datetime import date
import appsmanage as am

print('Welcome home ' + open('C__/orb/system32/.dat', 'r').readlines()[1])

cl = input('Would you like me to clear the console, i think it\'s a bit messy, yeah? (y/n)')
if cl == 'y':
    os.system('clear')
    print('Cleared')
else:
    print("Ok, if thats fine with you")

print('''
░█████╗░██████╗░██████╗░  ░█████╗░░██████╗  ██╗░░██╗░█████╗░███╗░░░███╗███████╗
██╔══██╗██╔══██╗██╔══██╗  ██╔══██╗██╔════╝  ██║░░██║██╔══██╗████╗░████║██╔════╝
██║░░██║██████╔╝██████╦╝  ██║░░██║╚█████╗░  ███████║██║░░██║██╔████╔██║█████╗░░
██║░░██║██╔══██╗██╔══██╗  ██║░░██║░╚═══██╗  ██╔══██║██║░░██║██║╚██╔╝██║██╔══╝░░
╚█████╔╝██║░░██║██████╦╝  ╚█████╔╝██████╔╝  ██║░░██║╚█████╔╝██║░╚═╝░██║███████╗
░╚════╝░╚═╝░░╚═╝╚═════╝░  ░╚════╝░╚═════╝░  ╚═╝░░╚═╝░╚════╝░╚═╝░░░░░╚═╝╚══════╝
''')
print('Today is ' + str(date.today()))

while True:
    print('[1] Open app\n[2] Shutdown')
    do = input('Option: ')
    if do == '1':
        print(open('C__/orb/system32/.dat', 'r').readlines()[3] + ' are the apps you have installed.')
        app = input('Select an app: ')
        am.run(app, 'open')
    elif do == '2':
        print('Stopping')
        break